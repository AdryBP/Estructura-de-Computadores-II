				
					****PRINCIPALES ADICIONES AL PROYECTO****


	Las principales adiciones al proyecto en esta entrega extraordinaria son tres:
	
		· Uso de memoria secundaria: En esta segunda entrega el juego cuenta con una puntuación máxima que se guarda en
		un archivo de texto en memoria secundaria. De este modo el programa cuenta con una variable que contiene la 
		puntuación que se inicializa a 0 y que se actualiza en la inicialización del programa. Además, esta variable se 
		actualiza una vez la puntuación de la partida actual la supera y una vez se acaba la partida, ya sea por haber entrado 
		en contacto con una pared o por haber alcanzado la longitud máxima, se escribe la nueva puntuación máxima en el 
		archivo de texto guardado en memoria secundaria. 

		· Framerate dinámico: También hemos incluido la parte obligatoria de esta segunda entrega; adaptar el framerate a la
		velocidad del ordenador. Para ello  hemos incluido un MAIN2.X68 dónde se contempla este detalle. Para llevar a cabo
		esta adaptación la estrategia es saltarse el PLOT un cierto número de veces, de manera que el juego solo hace el 
		UPDATE y hace el PLOT cada cierto tiempo. Para ello hemos definido una constante, que determina el número máximo 
		de veces que se puede saltar el PLOT, y una variable que determina el número de veces que quedan por saltarse el 
		PLOT.  

		· Mejora de la memória: Además, se ha mejorado y adaptado la memória del proyecto tanto en contenido como 
		formalmente.